# P5开发文档——小指令集流水线CPU

## Ⅰ 整体架构设计

### 一、数据通路设计

流水线的数据通路其实和单周期差距不大，核心区别就是每一部分之间插入了流水寄存器。本次实验中，除了一些微小的改动（如将cmp前移）都复用了P4的模块。

#### 1. 各个模块定义及说明

##### a) 取指器IFU

|      Pin       | I/O  |   Definition   |                       Note                        |
| :------------: | :--: | :------------: | :-----------------------------------------------: |
|      clk       |  I   |    时钟信号    |                         -                         |
|     reset      |  I   |  异步复位信号  |                         -                         |
|   imm [31:0]   |  I   |   偏移立即数   |                         -                         |
|    op [1:0]    |  I   |    操作信号    | 0: PC=PC+4;  1: PC=PC+4+imm\|\|$$0^2$$; 2: PC=imm |
| fetched [31:0] |  O   | 当前得到的指令 |                         -                         |

##### b) 寄存器堆GRF

|    Pin     | I/O  |     Definition      |         Note          |
| :--------: | :--: | :-----------------: | :-------------------: |
|    clk     |  I   |      时钟信号       |           -           |
|   reset    |  I   |    异步复位信号     |    1: 复位 0: 无效    |
|   enable   |  I   |     写使能信号      | 1: 可写入 0: 不能写入 |
| RA1 [4:0]  |  I   | 将此寄存器读出到RD1 |           -           |
| RA2 [4:0]  |  I   | 将此寄存器读出到RD2 |           -           |
| WA3 [4:0]  |  I   |  将WD写入此寄存器   |           -           |
| WD [31:0]  |  I   |      写入数据       |           -           |
| RD1 [31:0] |  O   |  RA1寄存器读出数据  |           -           |
| RD2 [31:0] |  O   |  RA2寄存器读出数据  |           -           |

##### c) 位扩展单元EXT

|     Pin      | I/O  |  Definition  |                             Note                             |
| :----------: | :--: | :----------: | :----------------------------------------------------------: |
| in16 [15:0]  |  I   | 16位被扩展数 |                              -                               |
| in26 [25:0]  |  I   | 26位被扩展数 |                                                              |
|   op [2:0]   |  I   |   扩展信号   | 0: 逻辑扩展16位 1: 符号扩展16位 2: 加载到高位 3: 逻辑扩展26位 |
| out32 [31:0] |  O   |   扩展结果   |                              -                               |

##### d) 比较单元CMP

|     Pin      | I/O  | Definition |          Note           |
| :----------: | :--: | :--------: | :---------------------: |
| num1 [31:0]  |  I   |  比较数1   |            -            |
| num2 [31:0]  |  I   |  比较数2   |            -            |
| result [2:0] |  O   |  比较结果  | 0：大于 1：等于 2：小于 |

##### e) 计算单元ALU

|      Pin      | I/O  | Definition |                    Note                    |
| :-----------: | :--: | :--------: | :----------------------------------------: |
|  num1 [31:0]  |  I   |  计算数1   |                     -                      |
|  num2 [31:0]  |  I   |  计算数2   |                     -                      |
|   op [2:0]    |  I   |  计算信号  | 0: add;  1: sub;  2: or;  3: and;  4: xor; |
| result [31:0] |  O   |  计算结果  |                     -                      |

##### d) 数据存储器DM

|      Pin       | I/O  |  Definition  |                     Note                      |
| :------------: | :--: | :----------: | :-------------------------------------------: |
|      clk       |  I   |   时钟信号   |                       -                       |
|     reset      |  I   | 异步复位信号 |                       -                       |
|     enable     |  I   |  写使能信号  | 信号为1时，时钟上升沿将数据写入地址所在的内存 |
| address [31:0] |  I   |  存/取地址   |                       -                       |
|   WD [31:0]    |  I   |  要写的数据  |                       -                       |
|   RD [31:0]    |  O   | 地址数据输出 |                       -                       |

#### 2. 主控制器

采用分布译码的方式，即一级实例化一个控制器，连出所需要的信号。这样虽然实际上会导致成本上升、效率降低的问题，但降低了工程复杂度。

|     指令类型      | ADDU | SUBU | ORI  |  LW  |  SW  | BEQ  | LUI  |  JR  | JAL  |  J   |
| :---------------: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: |
|   IFU.op [2:0]    | 000  | 000  | 000  | 000  | 000  | 001  | 000  | 011  | 010  | 010  |
|   ALU.op [2:0]    | 000  | 001  | 010  | 000  | 000  | xxx  | 000  | 000  | xxx  | xxx  |
|   EXT.op [2:0]    | xxx  | xxx  | 000  | 001  | 001  | 001  | 010  | xxx  | 011  | 011  |
|       DM.en       |  0   |  0   |  0   |  0   |  1   |  0   |  0   |  0   |  0   |  0   |
|      GRF.en       |  1   |  1   |  1   |  1   |  0   |  0   |  1   |  0   |  1   |  0   |
| GRF.WD_mux [2:0]  | 000  | 000  | 000  | 001  | xxx  | xxx  | 000  | xxx  | 010  | xxx  |
| GRF.WA3_mux[2:0]  | 001  | 001  | 000  | 000  | xxx  | xxx  | 000  | xxx  | 010  | xxx  |
| ALU.num2_mux[2:0] | 000  | 000  | 001  | 001  | 001  | 000  | 001  | 000  | xxx  | xxx  |
| IFU.imm_mux[2:0]  | xxx  | xxx  | xxx  | xxx  | xxx  | 000  | xxx  | 001  | 000  | 000  |

### 二、冒险处理

#### 1. 结构冒险

采用IM, DM分立即可。

#### 2. 控制冒险

采用延时槽，只需将JAL存值改为PC+8.

#### 3. 数据冒险

##### a) 暂停处理

采用AT法建模

指令的Tuse表如下（注：代码中将表格中'-'的值赋为5，即不需要暂停）

| Tuse\指令 | ADDU | SUBU | ORI  |  LW  |  SW  | BEQ  | LUI  |  JR  | JAL  |  J   |
| :-------: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: |
|    RD1    |  1   |  1   |  1   |  1   |  1   |  0   |  -   |  0   |  -   |  -   |
|    RD2    |  1   |  1   |  -   |  -   |  2   |  0   |  -   |  -   |  -   |  -   |

根据功能部件指令在E级的Tnew表如下（注：代码中将表格中'-'的值赋为0，即不需暂停）

|   指令   | ADDU | SUBU | ORI  |  LW  |  SW  | BEQ  | LUI  |  JR  | JAL  |  J   |
| :------: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: |
| 功能部件 | ALU  | ALU  | ALU  |  DM  |  -   |  -   | ALU  |  -   |  PC  |  -   |

| 产生数据功能部件 |  PC  | ALU  |  DM  |
| :--------------: | :--: | :--: | :--: |
|       Tnew       |  0   |  1   |  2   |

在D级译码并判断，暂停当且仅当存在转发位点的寄存器写址相同且Tuse<Tnew.

##### b) 转发处理

在假定暂停正确，所有需要转发的数据都已生成，按优先级由新到旧的次序暴力转发。

几个值得注意的地方：

1. EX级ALU输入的num2既需要控制器选择，又需要转发选择，转发应在上游。
2. ID级的接收的转发应作为寄存器读出的RD1和RD2的值，而不只是CMP的两个比较数。

3. EX和ME的PC+8要转发。其中由于只有JAL能在EX就产生结果，故不必选择；而ME被转发的值可能由ALU产生也可能是PC+8，故需要选择。

## Ⅱ 测试

### 一、指令功能测试

用三步测试基本的指令功能，基本和P4相同。

#### Part 1 测试基本计算指令

本部分测试基本计算指令集：{ori, addu, subu, lui, nop}

测试代码自动随机生成，C代码如下

```C
#include<stdio.h>
#include<stdlib.h>
#include<time.h>
int getreg()
{
	return rand()%32;
}
int getimm16()
{
	return rand()%(0xffff+1);
}
int getins(int n)
{
	return rand()%n;
}
int main()
{
	FILE *out = fopen("code.asm","w");
	int t,n;
	printf("Size of instruction set: ");
	scanf("%d",&n);
	printf("Total instruction number: ");
	scanf("%d",&t);
	srand((unsigned int)(time(NULL)));
	fprintf(out,"ori $28, $0, 0\n");// 为了让寄存器最终值和MARS相同
	fprintf(out,"ori $29, $0, 0\n");
    for(int i=0;i<t;i++)
	{
		switch(getins(n))
		{
			case 0: fprintf(out,"ori $%d, $%d, %d \n",getreg(),getreg(),getimm16()); break;
			case 1: fprintf(out,"subu $%d, $%d, $%d \n",getreg(),getreg(),getreg()); break;
			case 2: fprintf(out,"addu $%d, $%d, $%d \n",getreg(),getreg(),getreg()); break;
			case 3: fprintf(out,"lui $%d, %d \n",getreg(),getimm16()); break;
			case 4: fprintf(out,"nop \n"); break;
		}
	}
}
```

#### Part 2 测试访存指令及分支指令(Branch)

在认为上一部分的基本计算指令已经正确的基础上，本部分测试{sw, lw, beq}，测试代码如下

```assembly
ori $t0,$t0,30 
ori $t1,$t1,2 
ori $t2,$t2,1
ori $t3,$t3,1
ori $sp,$0,0
ori $t4,$t4,4  
addu $t5,$t3,$zero  
addu $s0,$zero,$sp  
sw $t2,0($sp)
addu $sp,$sp,$t4
sw $t3,0($sp)
addu $sp,$sp,$t4
for_begin:
	beq $t0,$t1,for_end
	lw $t2,-8($sp)
	lw $t3,-4($sp)
	addu $t6,$t2,$t3
	sw $t6,0($sp)
	addu $sp,$sp,$t4
	addu $t1,$t1,$t5
	beq $t0,$t0,for_begin
for_end:
```

#### Part 3 测试跳转指令(Jump)

本部分测试{Jal, Jr}，用一个递归计算等差数列求和公式的程序测试，测试代码如下

```Assembly
.data
	.space 8
	array: .space 4

.macro push(%reg)
	sw %reg, 0($sp)
	ori $t7, $0, 4
	subu $sp, $sp, $t7
.end_macro
.macro pop(%reg)
	ori $t7, $0, 4
	addu $sp, $sp, $t7
	lw %reg, 0($sp)
.end_macro
	
.macro to_function(%lable, %reg)
	push($a1)
	push($ra)
	addu $a1, %reg, $0
	jal %lable
	pop($ra)
	pop($a1)
.end_macro
.macro function_begin(%lable)
	%lable :
	push($s0)
	push($s1)
	push($s2)
.end_macro
.macro function_end(%reg)
	addu $v1, $0, %reg
	pop($s2)
	pop($s1)
	pop($s0)
	jr $ra
.end_macro
	
.text
	ori $sp, $0, 4000
	ori $t1, 9
	to_function(fact, $t1)
	sw $v1, array($0)
	jal end
	
	function_begin(fact)
		beq $a1, $0, to_end
			ori $s0, $0, 1
			subu $s1, $a1, $s0
			to_function(fact, $s1)
			addu $s1, $v1, $0
			addu $s1, $s1, $a1
			function_end($s1)
		to_end:
			function_end($0)
	
	end:
```

### 二、暂停与转发测试

本部分旨在测试流水线必要暂停时以及转发是否执行正确。没有覆盖需转发的指令，但覆盖了转发源和目标。代码如下

```assembly
ori $0, $0, 0
ori $1, $0, 1
ori $2, $0, 2
ori $3, $0, 3
ori $4, $0, 4
sw $5, 20($0)
sw $6, 24($0)
sw $7, 28($0)
sw $8, 32($0)
sw $9, 36($0)
block1: 
	#Stall test
	lw $1, 36($0)
	addu $16, $1, $1
	lw $1, 32($0)
	subu $16, $1, $9
	lw $1, 28($0)
	ori $16, $1, 135
block2:
	#Stall test
	#Forward from EX/ME to ID
	ori $3, $0, 174
	ori $4, $0, 174
	beq $3, $4, end2
	nop
	ori $1, $0, 1
	end2:
	ori $3, $0, 0x3064
	jr $3
	nop
	addu $1, $1, $1
	subu $1, $1, $2

block3:
	#Forward from EX/ME to EX
	jal mid3
	addu $1, $31, $1
	ori $1, $1, 1
	mid3:
	
block4:
	#Forward from EX/ME to EX
	addu $1, $3, $4
	addu $1, $1, $1
	ori $1, $1, 845
	subu $1, $3, $1

block5:
	#Forward from ME/WB to ME
	#	 and from ME/WB to EX
	ori $1, $0, 4
	sw $1, 0($1)
	sw $1, 0($1)
	addu $1, $1, $1
	sw $1, 0($1)
	sw $1, 0($1)
	
block6:
	#Forward from ME/WB to ID (Internal Forward of GRF)
	addu $2, $2, $1
	nop
	nop
	addu $3, $2, $2
```

## Ⅲ 思考题

### 流水线冒险

#### 1. 在采用本节所述的控制冒险处理方式下，PC的值应当如何被更新？请从数据通路和控制信号两方面进行说明。

由IF/ID寄存器的指令读出控制信号，控制方法和单周期相同，选择PC前的多路选择器即可。

#### 2. 对于jal等需要将指令地址写入寄存器的指令，为什么需要回写PC+8？

因为若编译器做了编译调度优化的话，希望的是延迟槽位置的指令只执行一次。如果回写了PC+4，则会执行两次，因此要+8跳过延迟槽内的指令。

### 数据冒险的分析

#### 1. 为什么所有的供给者都是存储了上一级传来的各种数据的**流水级寄存器**，而不是由ALU或者DM等部件来提供数据？

因为若由ALU或DM部件的输出端提供数据，虽然会早一周期得到，但是会导致一周期内需要经过两个组合逻辑部件。根据木桶原理，需要增大时钟周期，降低流水线整体效率。

### AT法处理流水线数据冒险

#### 1. Thinking

##### 1) 如果不采用已经转发过的数据，而采用上一级中的原始数据，会出现怎样的问题？试列举指令序列说明这个问题。

可能会导致一些寄存器的值在需要时，转发源已经离开了流水线。

比如

``` assembly
ori $5, $0, 5
ori $6, $0, 1
addu $6, $5, $5
nop
sw $6, 0($0)
```

正常应存入值10；但若EX/ME寄存器没有保存转发过的数据，而保存了原始数据，则会存入值1.

##### 2) 我们为什么要对GPR采用内部转发机制？如果不采用内部转发机制，我们要怎样才能解决这种情况下的转发需求呢？

因为GPR即作为最后一级流水线寄存器，又作为D级的组合逻辑。事实上内部转发就是将最后一级寄存器转发给D级。

##### 3) 为什么0号寄存器需要特殊处理？

因为对0号寄存器的写入信号应当被忽略，而如果直接转发则相当于某条指令会当作0号寄存器有非零值运行，这与0号寄存器的定义不符。

##### 4) 什么是“最新产生的数据”？

上游的流水寄存器的数据，即先进入流水线的指令产生的数据。

#### 2. 在AT方法讨论转发条件的时候，只提到了“供给者需求者的A相同，且不为0”，但在CPU写入GRF的时候，是有一个we信号来控制是否要写入的。为何在AT方法中不需要特判we呢？为了**用且仅用**A和T完成转发，在翻译出A的时候，要结合we做什么操作呢？

当WE为0时，令翻译得到A为0；反之正常翻译。

