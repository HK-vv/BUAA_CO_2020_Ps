/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "C:/Users/vv/Desktop/Archives/CS/Computer Organization_Y2S1/P5/Pipeline_CPU/data_path/CMP.v";
static unsigned int ng1[] = {0U, 0U};
static unsigned int ng2[] = {1U, 0U};
static unsigned int ng3[] = {2U, 0U};
static unsigned int ng4[] = {7U, 7U};



static void Cont_8_0(char *t0)
{
    char t3[8];
    char t4[8];
    char t9[8];
    char t25[8];
    char t26[8];
    char t30[8];
    char t61[8];
    char t62[8];
    char t68[8];
    char *t1;
    char *t2;
    char *t6;
    char *t8;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    unsigned int t13;
    unsigned int t14;
    char *t15;
    char *t16;
    unsigned int t17;
    unsigned int t18;
    unsigned int t19;
    char *t20;
    unsigned int t21;
    unsigned int t22;
    unsigned int t23;
    unsigned int t24;
    char *t27;
    char *t28;
    char *t29;
    char *t31;
    unsigned int t32;
    unsigned int t33;
    unsigned int t34;
    unsigned int t35;
    unsigned int t36;
    unsigned int t37;
    unsigned int t38;
    unsigned int t39;
    unsigned int t40;
    unsigned int t41;
    unsigned int t42;
    unsigned int t43;
    char *t44;
    char *t45;
    unsigned int t46;
    unsigned int t47;
    unsigned int t48;
    unsigned int t49;
    unsigned int t50;
    char *t51;
    char *t52;
    unsigned int t53;
    unsigned int t54;
    unsigned int t55;
    char *t56;
    unsigned int t57;
    unsigned int t58;
    unsigned int t59;
    unsigned int t60;
    char *t64;
    char *t65;
    char *t67;
    unsigned int t69;
    unsigned int t70;
    unsigned int t71;
    unsigned int t72;
    unsigned int t73;
    char *t74;
    char *t75;
    unsigned int t76;
    unsigned int t77;
    unsigned int t78;
    char *t79;
    unsigned int t80;
    unsigned int t81;
    unsigned int t82;
    unsigned int t83;
    char *t84;
    char *t85;
    char *t86;
    char *t87;
    char *t88;
    char *t89;
    unsigned int t90;
    unsigned int t91;
    char *t92;
    unsigned int t93;
    unsigned int t94;
    char *t95;
    unsigned int t96;
    unsigned int t97;
    char *t98;

LAB0:    t1 = (t0 + 2528U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(8, ng0);
    t2 = (t0 + 1048U);
    t6 = *((char **)t2);
    t2 = (t0 + 1208U);
    t8 = *((char **)t2);
    memset(t9, 0, 8);
    xsi_vlog_signed_greater(t9, 32, t6, 32, t8, 32);
    memset(t4, 0, 8);
    t2 = (t9 + 4);
    t10 = *((unsigned int *)t2);
    t11 = (~(t10));
    t12 = *((unsigned int *)t9);
    t13 = (t12 & t11);
    t14 = (t13 & 1U);
    if (t14 != 0)
        goto LAB4;

LAB5:    if (*((unsigned int *)t2) != 0)
        goto LAB6;

LAB7:    t16 = (t4 + 4);
    t17 = *((unsigned int *)t4);
    t18 = *((unsigned int *)t16);
    t19 = (t17 || t18);
    if (t19 > 0)
        goto LAB8;

LAB9:    t21 = *((unsigned int *)t4);
    t22 = (~(t21));
    t23 = *((unsigned int *)t16);
    t24 = (t22 || t23);
    if (t24 > 0)
        goto LAB10;

LAB11:    if (*((unsigned int *)t16) > 0)
        goto LAB12;

LAB13:    if (*((unsigned int *)t4) > 0)
        goto LAB14;

LAB15:    memcpy(t3, t25, 8);

LAB16:    t85 = (t0 + 2928);
    t86 = (t85 + 56U);
    t87 = *((char **)t86);
    t88 = (t87 + 56U);
    t89 = *((char **)t88);
    memset(t89, 0, 8);
    t90 = 7U;
    t91 = t90;
    t92 = (t3 + 4);
    t93 = *((unsigned int *)t3);
    t90 = (t90 & t93);
    t94 = *((unsigned int *)t92);
    t91 = (t91 & t94);
    t95 = (t89 + 4);
    t96 = *((unsigned int *)t89);
    *((unsigned int *)t89) = (t96 | t90);
    t97 = *((unsigned int *)t95);
    *((unsigned int *)t95) = (t97 | t91);
    xsi_driver_vfirst_trans(t85, 0, 2);
    t98 = (t0 + 2848);
    *((int *)t98) = 1;

LAB1:    return;
LAB4:    *((unsigned int *)t4) = 1;
    goto LAB7;

LAB6:    t15 = (t4 + 4);
    *((unsigned int *)t4) = 1;
    *((unsigned int *)t15) = 1;
    goto LAB7;

LAB8:    t20 = ((char*)((ng1)));
    goto LAB9;

LAB10:    t27 = (t0 + 1048U);
    t28 = *((char **)t27);
    t27 = (t0 + 1208U);
    t29 = *((char **)t27);
    memset(t30, 0, 8);
    t27 = (t28 + 4);
    t31 = (t29 + 4);
    t32 = *((unsigned int *)t28);
    t33 = *((unsigned int *)t29);
    t34 = (t32 ^ t33);
    t35 = *((unsigned int *)t27);
    t36 = *((unsigned int *)t31);
    t37 = (t35 ^ t36);
    t38 = (t34 | t37);
    t39 = *((unsigned int *)t27);
    t40 = *((unsigned int *)t31);
    t41 = (t39 | t40);
    t42 = (~(t41));
    t43 = (t38 & t42);
    if (t43 != 0)
        goto LAB20;

LAB17:    if (t41 != 0)
        goto LAB19;

LAB18:    *((unsigned int *)t30) = 1;

LAB20:    memset(t26, 0, 8);
    t45 = (t30 + 4);
    t46 = *((unsigned int *)t45);
    t47 = (~(t46));
    t48 = *((unsigned int *)t30);
    t49 = (t48 & t47);
    t50 = (t49 & 1U);
    if (t50 != 0)
        goto LAB21;

LAB22:    if (*((unsigned int *)t45) != 0)
        goto LAB23;

LAB24:    t52 = (t26 + 4);
    t53 = *((unsigned int *)t26);
    t54 = *((unsigned int *)t52);
    t55 = (t53 || t54);
    if (t55 > 0)
        goto LAB25;

LAB26:    t57 = *((unsigned int *)t26);
    t58 = (~(t57));
    t59 = *((unsigned int *)t52);
    t60 = (t58 || t59);
    if (t60 > 0)
        goto LAB27;

LAB28:    if (*((unsigned int *)t52) > 0)
        goto LAB29;

LAB30:    if (*((unsigned int *)t26) > 0)
        goto LAB31;

LAB32:    memcpy(t25, t61, 8);

LAB33:    goto LAB11;

LAB12:    xsi_vlog_unsigned_bit_combine(t3, 3, t20, 3, t25, 3);
    goto LAB16;

LAB14:    memcpy(t3, t20, 8);
    goto LAB16;

LAB19:    t44 = (t30 + 4);
    *((unsigned int *)t30) = 1;
    *((unsigned int *)t44) = 1;
    goto LAB20;

LAB21:    *((unsigned int *)t26) = 1;
    goto LAB24;

LAB23:    t51 = (t26 + 4);
    *((unsigned int *)t26) = 1;
    *((unsigned int *)t51) = 1;
    goto LAB24;

LAB25:    t56 = ((char*)((ng2)));
    goto LAB26;

LAB27:    t64 = (t0 + 1048U);
    t65 = *((char **)t64);
    t64 = (t0 + 1208U);
    t67 = *((char **)t64);
    memset(t68, 0, 8);
    xsi_vlog_signed_less(t68, 32, t65, 32, t67, 32);
    memset(t62, 0, 8);
    t64 = (t68 + 4);
    t69 = *((unsigned int *)t64);
    t70 = (~(t69));
    t71 = *((unsigned int *)t68);
    t72 = (t71 & t70);
    t73 = (t72 & 1U);
    if (t73 != 0)
        goto LAB34;

LAB35:    if (*((unsigned int *)t64) != 0)
        goto LAB36;

LAB37:    t75 = (t62 + 4);
    t76 = *((unsigned int *)t62);
    t77 = *((unsigned int *)t75);
    t78 = (t76 || t77);
    if (t78 > 0)
        goto LAB38;

LAB39:    t80 = *((unsigned int *)t62);
    t81 = (~(t80));
    t82 = *((unsigned int *)t75);
    t83 = (t81 || t82);
    if (t83 > 0)
        goto LAB40;

LAB41:    if (*((unsigned int *)t75) > 0)
        goto LAB42;

LAB43:    if (*((unsigned int *)t62) > 0)
        goto LAB44;

LAB45:    memcpy(t61, t84, 8);

LAB46:    goto LAB28;

LAB29:    xsi_vlog_unsigned_bit_combine(t25, 3, t56, 3, t61, 3);
    goto LAB33;

LAB31:    memcpy(t25, t56, 8);
    goto LAB33;

LAB34:    *((unsigned int *)t62) = 1;
    goto LAB37;

LAB36:    t74 = (t62 + 4);
    *((unsigned int *)t62) = 1;
    *((unsigned int *)t74) = 1;
    goto LAB37;

LAB38:    t79 = ((char*)((ng3)));
    goto LAB39;

LAB40:    t84 = ((char*)((ng4)));
    goto LAB41;

LAB42:    xsi_vlog_unsigned_bit_combine(t61, 3, t79, 3, t84, 3);
    goto LAB46;

LAB44:    memcpy(t61, t79, 8);
    goto LAB46;

}


extern void work_m_00000000001843262212_1579609468_init()
{
	static char *pe[] = {(void *)Cont_8_0};
	xsi_register_didat("work_m_00000000001843262212_1579609468", "isim/tb_isim_beh.exe.sim/work/m_00000000001843262212_1579609468.didat");
	xsi_register_executes(pe);
}
